<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Vpermiso extends Model
{
    protected $table='vpermisos';
    protected $primaryKey=null;
    public $incrementing = false; 

}
